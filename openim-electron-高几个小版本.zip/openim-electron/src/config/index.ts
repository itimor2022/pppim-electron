// WS 10001 API 10002 CHAT 10008 CONFIG 10009

// export const WS_URL = "ws://admin.skjdffsdfs.top/msg_gateway_enterprise";
// export const API_URL = "http://admin.skjdffsdfs.top/api_enterprise";
// export const CHAT_URL = "http://admin.skjdffsdfs.top/chat_enterprise";

export const WS_URL = "wss://154.201.84.21/msg_gateway";
export const API_URL = "https://154.201.84.21/api";
export const CHAT_URL = "https://154.201.84.21/chat";

// export const WS_URL = "ws://47.97.206.63:10001/msg_gateway";
// export const API_URL = "http://47.97.206.63:10002/api";
// export const CHAT_URL = "http://47.97.206.63:10002/chat";
export const getWsUrl = () => localStorage.getItem("wsUrl") || WS_URL;
export const getApiUrl = () => localStorage.getItem("apiUrl") || API_URL;
export const getChatUrl = () => localStorage.getItem("chatUrl") || CHAT_URL;

export const APP_VERSION = "光联 v2.0";
export const APP_VERSION_CODE = 350;
export const SDK_VERSION = "SDK v2.0";
export const CHECK_UPDATE_PREFIX =
  "https://app-1302656840.cos.ap-nanjing.myqcloud.com/";

export const isSaveLog = true;
