declare module "@twemoji/parser";
